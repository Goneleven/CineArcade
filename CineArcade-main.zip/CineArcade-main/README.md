# CineArcade
Projeto UMC | 2º Semestre | MySQL, C#

<hr>

<H3>FORMATAÇÃO PARA O BANCO DE DADOS:</H3>
<p>(Descrição temporaria, Vou tirar depois)</p>

DATABASE | COMANDOS: "<b><i>EXEMPLO</i></b>";<br>
TABELA: "<b><i>Exemplo</i></b>";<br>
ATRIBUTOS: "<b><i>exemplo</i></b>";<br>

<h3>Exemplo em um Contexto Geral:</h3>

CREATE DATABASE <b><i>CINEARCADE</i></b>;

USE <b><i>CINEARCADE</i></b>;

CREATE TABLE <b><i>Clientes</i></b>(<br>
ㅤㅤ<b><i>id</i></b> INT PRIMARY KEY,<br>
ㅤㅤ<b><i>nome</i></b> VARCHAR(30)<br>
);
<hr>
